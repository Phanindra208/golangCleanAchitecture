package gommon
