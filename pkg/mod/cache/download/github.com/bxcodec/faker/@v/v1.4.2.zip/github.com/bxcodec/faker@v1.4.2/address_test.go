package faker

import (
	"testing"
)

func TestFakeData(t *testing.T) {
	SetAddress(Address{})
}
